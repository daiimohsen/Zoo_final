
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Animal {
    String id;
    String name;
    String nationallity;
    String sex;
    String national_id;
    String food;

   
    String department;
    Boolean insurance;

    public Animal() {
    }
    
     public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Animal (String id,String name,String nationallity,String sex,String nationsl_id,String food,String department,Boolean insurance){
        this.id=id;
        this.name=name;
        this.nationallity=nationallity;
        this.sex=sex;
        this.national_id=nationsl_id;
        this.food=food;
        this.department=department;
        this.insurance=insurance;
    }
    
    public String getNationallity() {
        return nationallity;
    }

    public void setNationallity(String nationallity) {
        this.nationallity = nationallity;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getNational_id() {
        return national_id;
    }

    public void setNational_id(String national_id) {
        this.national_id = national_id;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Boolean getInsurance() {
        return insurance;
    }

    public void setInsurance(Boolean insurance) {
        this.insurance = insurance;
    }

public static void read() throws Exception {
        FileReader fr = new FileReader("Animal.txt");
        BufferedReader br = new BufferedReader(fr);
        String line, str[];

        while ((line = br.readLine()) != null) {

            str = line.split("     ");
            Boolean b=true;
            Animal s1 = new Animal(str[0], str[1], str[2], str[3], str[4], str[5], str[6],b );
            Login.animals.add(s1);
        }

        br.close();
        System.out.println("All files Of Animals have been read!!!");
    }
    
    public static void write() throws IOException {
        String line;
        FileWriter fw = new FileWriter("Animal.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        for (Animal s1 : Login.animals) {
            line = s1.getId() + "     " + s1.getName() + "     "
                    + "     " + s1.getFood() + "     " + s1.getNational_id() + "     " 
                    + "     " + s1.getNationallity() + "     " + s1.getSex()  ;

            bw.write(line);
            bw.newLine();
        }
        bw.flush();
        bw.close();
        System.out.println("All files Of Animals have been Write!!!");
    }
    
}
