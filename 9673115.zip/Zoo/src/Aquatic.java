
public class Aquatic extends Animal {
     private  Boolean camivorous;

    public Aquatic(String id ,String name,String nationallity, String sex, String national_id, String food, String department, Boolean insurance,Boolean camivorous) {
        super(id,name,nationallity, sex, national_id, food, department, insurance);
        
    }

    public Boolean getCamivorous() {
        return camivorous;
    }

    public void setCamivorous( Boolean camivorous) {
        this.camivorous = camivorous;
    }
}
