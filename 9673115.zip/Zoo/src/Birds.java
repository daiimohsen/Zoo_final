
public class Birds extends Animal{
    Boolean wild;

    public Birds(String id ,String name,String nationallity, String sex, String nationsl_id, String food, String department, Boolean insurance,Boolean wild) {
        super(id,name,nationallity, sex, nationsl_id, food, department, insurance);
        this.wild=wild;
    }

    public Boolean getWild() {
        return wild;
    }

    public void setWild(Boolean wild) {
        this.wild = wild;
    }
}
