
public class Aquatic_Departments extends Department{
    static int ticket_price;
    int count_Tickets;
    public Aquatic_Departments(String id, String name, int ticket_price) {
        super(id, name);
        this.ticket_price=ticket_price;
    }
    
    public Aquatic_Departments(String id, String name, int ticket_price,String count_tickets) {
        super(id, name);
        this.count_Tickets=count_Tickets;
    }

    int getTicket_price() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setTicket_price(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
