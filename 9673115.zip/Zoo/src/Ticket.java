
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohsen
 */
public class Ticket {
    String name;
    static int price;
    static int count;

    public Ticket(String name, int price,int count) {
        this.name = name;
        this.price = price;
        this.count=count;
    }
    public Ticket() {
        
        this.price = 5000;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
//    public static void read() throws Exception {
//        FileReader fr = new FileReader("Ticket.txt");
//        BufferedReader br = new BufferedReader(fr);
//        String line, str[];
//
//        while ((line = br.readLine()) != null) {
//
//            str = line.split("     ");
//            Ticket s1 = new Ticket(str[0],Integer.parseInt(line));
//            Login.tickets.add(s1);
//        }
//
//        br.close();
//        System.out.println("All files Of Tickets have been read!!!");
//    }
//    
//    public static void write() throws IOException {
//        String line;
//        FileWriter fw = new FileWriter("Ticket.txt");
//        BufferedWriter bw = new BufferedWriter(fw);
//        for (Ticket s1 : Login.tickets) {
//            line = s1.getName() + "     " + s1.getPrice() + "     ";
//                    
//            bw.write(line);
//            bw.newLine();
//        }
//        bw.flush();
//        bw.close();
//        System.out.println("All files Of Tickets have been Write!!!");
//    }

    
}
