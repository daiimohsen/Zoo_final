
public class Send_massage {
    String masssage;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    String id;

    public Send_massage(String massage) {
        this.masssage = masssage;
    }

    public Send_massage(String masssage, String id) {
        this.masssage = masssage;
        this.id = id;
    }

    public String getMasssage() {
        return masssage;
    }

    public void setMasssage(String masssage) {
        this.masssage = masssage;
    }

    
    
}
