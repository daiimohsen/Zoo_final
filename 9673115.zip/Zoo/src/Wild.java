
public class Wild extends Animal{
    String home;

    public Wild(String id ,String name,String nationallity, String sex, String nationsl_id, String food, String department, Boolean insurance,String home) {
        super(id,name,nationallity, sex, nationsl_id, food, department, insurance);
        this.home=home;
    }

    public String getHome() {
        return home;
    }

    public void setHome(String home) {
        this.home = home;
    }
    
}
