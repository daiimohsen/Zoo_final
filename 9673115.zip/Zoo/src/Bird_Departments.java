
public class Bird_Departments extends Department{
    int count_Tickets;
    static int ticket_price;
    public Bird_Departments(int count_Tickets,String id, String name) {
        super(id, name);
        this.count_Tickets = count_Tickets;
    }
    public Bird_Departments(String id, String name, int ticket_price) {
        super(id, name);
        this.ticket_price=ticket_price;
    }
    
}

