
import javax.swing.JFrame;

public class Zoo {
 static void main(String[] args) throws Exception {
        // TODO code application logic here
        
        JFrame login = new Login();
        login.setVisible(true);
        
    }
    
}
