
interface Showable {
    
   public void show();
    
   }
