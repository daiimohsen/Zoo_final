
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Zookeeper extends Person{
    String address;
    String wage;
    String department;
    
     public Zookeeper(String id,String username,String lastname,String name ,String Email, int phone_number, String password ,String address, String wage, String department   ) {
        super(id, username, lastname,name, Email, phone_number, password);
        this.address = address;
        this.wage = wage;
        this.department = department;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public int getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(int phone_number) {
        this.phone_number = phone_number;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    
  
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWage() {
        return wage; 
    }

    public void setWage(String wage) {
        this.wage = wage;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
    
    public static void read() throws Exception {
        FileReader fr = new FileReader("Zookeeper.txt");
        BufferedReader br = new BufferedReader(fr);
        String line, str[];

        while ((line = br.readLine()) != null) {

            str = line.split("     ");
            Zookeeper s1 = new Zookeeper(str[0], str[1], str[2], str[3], str[4], Integer.parseInt(line), str[6], str[7], str[8], str[9]);
            Login.zookeepers.add(s1);
        }

        br.close();
        System.out.println("All files Of Customer have been read!!!");
    }
    
    public static void write() throws IOException {
        String line;
        FileWriter fw = new FileWriter("Zookeeper.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        for (Zookeeper s1 : Login.zookeepers) {
            line = s1.getId() + "     " + s1.getName() + "     " + s1.getLastname()
                    + "     " + s1.getEmail() + "     " + s1.getPassword() + "     " + s1.getAddress()
                    + "     " + s1.getUsername() + "     " + s1.getWage() + "     " ;

            bw.write(line);
            bw.newLine();
        }
        bw.flush();
        bw.close();
        System.out.println("All files Of Customer have been Write!!!");
    }
}
