

public class Wild_Departments extends Department{
  
    static int zookeeper;

    public static int getZookeeper() {
        return zookeeper;
    }

    public static void setZookeeper(int zookeeper) {
        Wild_Departments.zookeeper = zookeeper;
    }
    
   
    public Wild_Departments(String id, String name) {
        super(id, name);
        }
    public Wild_Departments(String id, String name,int zookeper) {
        super(id, name);
        this.zookeeper=zookeeper;
        }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    public Wild_Departments(String count_Tickets, String id, String name) {
        super(id, name);
        
    }
    
    
}
