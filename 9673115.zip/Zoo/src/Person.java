
abstract class Person {
    String id;
    String username;
    String lastname;
    String name;
    String Email;
    int phone_number;
    String password;
    
    public Person(String id, String username, String lastname, String name, String Email, int phone_number, String password) {
        this.id = id;
        this.username = username;
        this.lastname = lastname;
        this.name = name;
        this.Email = Email;
        this.phone_number = phone_number;
        this.password = password;
    }
    public Person(String username,String password){
        this.username=username;
        this.password=password;
    }
    
    public Person(){
      
    }
   
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public int getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(int phone_number) {
        this.phone_number = phone_number;
    }
    
}
