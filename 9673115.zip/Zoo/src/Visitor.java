
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Visitor extends Person {
    int cash;
    int tickets;

    public int getTickets() {
        return tickets;
    }

    public void setTickets(int tickets) {
        this.tickets = tickets;
    }

    public Visitor( String id, String username, String lastname,String name, String Email, int phone_number, String password,int cash,int tivkets) {
        super(id, username, lastname,name, Email, phone_number, password);
        this.cash = cash;
        this.tickets=tickets;
    }   

    public Visitor() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public int getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(int phone_number) {
        this.phone_number = phone_number;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
   

    public int getCash() {
        return cash;
    }

    public void setCash(int cash) {
        this.cash = cash;
    }
////    public static void read() throws Exception {
////        FileReader fr = new FileReader("Visitor.txt");
////        BufferedReader br = new BufferedReader(fr);
////        String line, str[];
////
////        while ((line = br.readLine()) != null) {
////
////            str = line.split("     ");
////            Visitor s1 = new Visitor(str[0], str[1], str[2], str[3], str[4], Integer.parseInt(line), str[6], Integer.parseInt(line) );
////            Login.visitors.add(s1);
////        }
//
//        br.close();
//        System.out.println("All files Of Visitors have been read!!!");
//    }
//    
//    public static void write() throws IOException {
//        String line;
//        FileWriter fw = new FileWriter("Visitor.txt");
//        BufferedWriter bw = new BufferedWriter(fw);
//        for (Visitor s1 : Login.visitors) {
//            line = s1.getId() + "     " + s1.getName() + "     "
//                    + "     " + s1.getEmail() + "     " + s1.getLastname() + "     " 
//                    + "     " + s1.getUsername() + "     " + s1.getPassword() + "     "+s1.getCash()+s1.getPhone_number() ;
//
//            bw.write(line);
//            bw.newLine();
//        }
//        bw.flush();
//        bw.close();
//        System.out.println("All files Of Visitors have been Write!!!");
//    }
//    
}
