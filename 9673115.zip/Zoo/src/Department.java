abstract class Department {
    String id;
    String name;
    String zookeepers;
    // array lsit fro zookepers

    public Department(String id, String name, String zookeepers) {
        this.id = id;
        this.name = name;
        //this.ticket_price = ticket_price;
        this.zookeepers = zookeepers;
    }

    public String getZookeepers() {
        return zookeepers;
    }

    public void setZookeepers(String zookeepers) {
        this.zookeepers = zookeepers;
    }

    public Department(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
