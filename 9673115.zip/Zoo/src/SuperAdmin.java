
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class SuperAdmin {
    
    String username;
    String password;
    String email;
    

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public SuperAdmin(String username,String password,String email){
        this.username=username;
        this.password=password;
        this.email=email;
    }
    public static void read() throws Exception {
        FileReader fr = new FileReader("Manager.txt");
        BufferedReader br = new BufferedReader(fr);
        String line, str[];

        while ((line = br.readLine()) != null) {

            str = line.split("     ");
            Manager s1 = new Manager(str[0], str[1], str[2], str[3], str[4], Integer.parseInt(line), str[6], str[7], str[8]);
            Login.managers.add(s1);
        }

        br.close();
        System.out.println("All files Of superadmin have been read!!!");
    }
    
    public static void write() throws IOException {
        String line;
        FileWriter fw = new FileWriter("SuperAdmin.txt");
        BufferedWriter bw = new BufferedWriter(fw);
        for (SuperAdmin s1 : Login.superadmin) {
            line = s1.getUsername() + "     " + s1.getPassword() + "     "
                    + "     " + s1.getEmail() ;

            bw.write(line);
            bw.newLine();
        }
        bw.flush();
        bw.close();
        System.out.println("All files Of superadmin have been Write!!!");
    }

      
}
